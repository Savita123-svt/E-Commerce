import ComingSoon from "../ComingSoon";

const PaymentCards = () => {
    return <ComingSoon />;
};

export default PaymentCards;
