import ComingSoon from "../ComingSoon";
const Reviews = () => {
    return <ComingSoon />;
};

export default Reviews;
